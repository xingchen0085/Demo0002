This work was released by Stephen Challener (Redshrike) under the Creative Commons CC-BY 3.0 license.

The spritesheets, the three color variations and the idle cycle were made by Bonsaiheldin (http://bonsaiheld.org).

Enjoy!
